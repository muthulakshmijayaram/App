package com.example.mainproject.model;

public class recomendation {
}
